package relogio;

public class RunClock {

    public static void main(String[] args) {
        Tela t1 = new Tela();
        t1.setVisible(true);
        while(true)
        t1.oi();
    }

}
