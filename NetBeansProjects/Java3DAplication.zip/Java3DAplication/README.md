# RelogioAnalogicoJava
Mini Relógio Analógico Java usando paintComponents: drawLine e drawOval e equação de transformação linear para rotação.
https://www.youtube.com/watch?v=BOTXeYbu2JY
